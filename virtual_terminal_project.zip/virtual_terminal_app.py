
from flask import Flask, render_template_string, jsonify, request
from twilio.rest import Client
import os

app = Flask(__name__)

# Twilio credentials
TWILIO_ACCOUNT_SID = 'AC3d72e4d2aa6b9f278f184b8a46a53ad9'
TWILIO_AUTH_TOKEN = '1A7RZ1LDDMHEMZY3F6HLKH28'
TWILIO_PHONE_NUMBER = '+213554344554'

client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)

# File to store call data
TERMINAL_FILE = 'terminal_output.txt'

# HTML Page
HTML_PAGE = """
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Virtual Terminal - Intercept Call Data</title>
  <style>
    body {
      background-color: #222;
      font-family: 'Courier New', monospace;
      color: #0f0;
      margin: 0;
      padding: 0;
    }
    .terminal {
      width: 100%;
      height: 100vh;
      overflow-y: auto;
      padding: 20px;
      box-sizing: border-box;
      border: 1px solid #0f0;
      background-color: #111;
      color: #0f0;
    }
    .terminal pre {
      margin: 0;
      white-space: pre-wrap;
      word-wrap: break-word;
    }
    .input-line {
      display: flex;
      align-items: center;
    }
    .input-line::before {
      content: "root@server:";
      color: #0f0;
      margin-right: 10px;
    }
    input {
      background-color: #222;
      border: none;
      color: #0f0;
      width: 100%;
      font-size: 16px;
      padding: 5px;
    }
    input:focus {
      outline: none;
    }
  </style>
</head>
<body>

<div class="terminal" id="terminal">
  <pre>Welcome to the simulation terminal.
Type 'help' for commands.</pre>
  <div class="input-line">
    <input type="text" id="commandInput" placeholder="Enter command..." onkeydown="handleInput(event)">
  </div>
</div>

<script>
  const terminal = document.getElementById("terminal");
  const commandInput = document.getElementById("commandInput");

  function loadTerminalData() {
    fetch('/terminal_output')
      .then(response => response.text())
      .then(data => {
        terminal.innerHTML = `<pre>${data}</pre>`;
        terminal.scrollTop = terminal.scrollHeight; // Auto-scroll to the bottom
      });
  }

  function handleInput(event) {
    if (event.key === 'Enter') {
      const command = commandInput.value.trim();
      commandInput.value = '';

      if (command === 'help') {
        appendToTerminal('Available commands:\n- help: Show this message\n- showData: Show intercepted data');
      } else if (command === 'showData') {
        loadTerminalData();  // Load live data
      } else {
        appendToTerminal(`Command not found: ${command}`);
      }
    }
  }

  function appendToTerminal(message) {
    terminal.innerHTML += `<pre>${message}</pre>`;
    terminal.scrollTop = terminal.scrollHeight; // Auto-scroll to the bottom
  }
</script>

</body>
</html>
"""

# Terminal data page
@app.route('/terminal_output')
def terminal_output():
    try:
        with open(TERMINAL_FILE, 'r') as file:
            return file.read()
    except FileNotFoundError:
        return "No data available."

@app.route('/')
def home():
    return render_template_string(HTML_PAGE)

@app.route('/call', methods=['POST'])
def make_call():
    data = request.json
    to_number = data.get('to')

    # Custom audio URL
    audio_url = "https://your_storage_link_here.mp3"  # Your custom audio URL

    try:
        call = client.calls.create(
            to=to_number,
            from_=TWILIO_PHONE_NUMBER,
            url=audio_url  # Use the audio URL
        )
        append_to_terminal(f"[INFO] Call started with number: {to_number}")
        return jsonify({"status": "success", "sid": call.sid})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)})

def append_to_terminal(message):
    with open(TERMINAL_FILE, "a") as file:
        file.write(f"{message}\n")

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
